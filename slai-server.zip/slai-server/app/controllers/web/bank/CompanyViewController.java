package controllers.web.bank;

import java.util.List;
import controllers.web.WebController;
import entities.BranchList;
import models.Branch;
import models.Company;
import play.mvc.*;

public class CompanyViewController extends WebController {
    private String companyCode;
    
    public Result show(String companyCode) {
        this.companyCode = companyCode;
        return show();
    }

    public Result execute() {
        List<Branch> branchs = Branch.getByCompanyCode(companyCode);
        BranchList branchList = new BranchList();
        branchList.setBranchs(branchs);
        branchList.setCompanyCode(companyCode);
        Company company = Company.getByCompanyCode(companyCode);
        branchList.setCompanyName(company.getCompanyName());
        return Results.ok(views.html.branchs.render(branchList));
    }
}
