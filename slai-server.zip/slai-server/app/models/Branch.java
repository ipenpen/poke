package models;

import java.util.Date;
import java.util.List;
import javax.persistence.*;
import com.avaje.ebean.Model;
import com.avaje.ebean.annotation.DbComment;
import play.data.format.Formats;

@SuppressWarnings("deprecation")
@Entity
@DbComment("会社の支店")
public class Branch extends Model {
    @Id
    private long id;
    
    @ManyToOne
    @DbComment("会社コード")
    private Company company;
    
    @Column(columnDefinition = "varchar(10)")
    @DbComment("支店コード")
    private String branchCode;
    
    @Column(columnDefinition = "varchar(255)")
    @DbComment("支店名称")
    private String branchName;
    
    @Column(columnDefinition = "varchar(400)")
    @DbComment("支店説明")
    private String description;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("登録日時")
    private Date registedTime = new Date();

    @Column(columnDefinition = "varchar(20)")
    @DbComment("登録ユーザーID")
    private String registedUserId = null;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("更新日時")
    private Date updatedTime = new Date();

    @Column(columnDefinition = "varchar(20)")
    @DbComment("更新ユーザーID")
    private String updatedUserId = null;

    /* function */
    public static Finder<String, Branch> find = new Finder<>(String.class, Branch.class);
    
    public static List<Branch> getByCompanyCode(String companyCode) {
        return Branch.find.where().eq("company_company_code", companyCode).findList();
    }
    
    public static Branch getByCompanyCodeAndBranchCode(String companyCode, String branchCode) {
        return Branch.find.where().eq("company_company_code", companyCode).eq("branch_code", branchCode).findUnique();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getRegistedTime() {
        return registedTime;
    }

    public void setRegistedTime(Date registedTime) {
        this.registedTime = registedTime;
    }

    public String getRegistedUserId() {
        return registedUserId;
    }

    public void setRegistedUserId(String registedUserId) {
        this.registedUserId = registedUserId;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getUpdatedUserId() {
        return updatedUserId;
    }

    public void setUpdatedUserId(String updatedUserId) {
        this.updatedUserId = updatedUserId;
    }
}