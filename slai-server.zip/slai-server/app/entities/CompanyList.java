package entities;

import java.util.ArrayList;
import java.util.List;
import models.Company;

public class CompanyList {
    private List<Company> companies = new ArrayList<Company>();

    public List<Company> getCompanies() {
        return companies;
    }

    public void setCompanies(List<Company> companies) {
        this.companies = companies;
    }
}
