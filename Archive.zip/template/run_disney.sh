#!/usr/bin/env bash

# Starts PokemonGo-Bot
config=""

if [ ! -z $1 ]; then
    config=$1
else
    config="./configs/CONFIG_FILE_NAME"
    if [ ! -f ${config} ]; then
        echo -e "There's no config file"
        exit 1
    fi
fi

until (python pokecli.py --config ${config}); do
    echo "Process crashed with exit code $?.  Respawning.." >&2
    sleep 1800
done
