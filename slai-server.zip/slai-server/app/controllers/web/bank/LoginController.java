package controllers.web.bank;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import models.BankUser;
import play.data.DynamicForm;
import play.data.Form;
import play.i18n.Messages;
import play.mvc.*;

public class LoginController extends Controller {
    
    public Result show() {
        session().clear();
        return Results.ok(views.html.login.render(null));
    }
    
    public Result post() {
        DynamicForm form = Form.form().bindFromRequest();
        String userName = form.get("user");
        String password = form.get("pass");
        BankUser user = BankUser.getByUserName(userName);
        if (user == null) {
            return Results.ok(views.html.login.render(Messages.get("login.wrong")));
        } else {
            String hashedPassword = getHashString(password.getBytes());
            if (!hashedPassword.equals(user.getPassword())) {
                return Results.ok(views.html.login.render(Messages.get("login.wrong")));
            }
        }
        
        session().put("username", userName);
        session().put("bankCode", user.getBank().getBankCode());
    
        return Results.redirect("/");
    }
    
    private String getHashString(byte[] bytes) {
        if (bytes.length == 0) {
            return "";
        }
        // TODO: 作成時間を追加して強化する
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
        }
        
        byte[] mdbytes = md.digest(bytes);

        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < mdbytes.length; i++) {
          sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
        }

        return sb.toString();
    }
}
