package controllers.web;

import models.BankUser;
import play.mvc.*;

public class WebController extends Controller {
    protected BankUser user = null;
    
    public Result show() {
        // アクセス権限確認
        if (!isValidPermission()) {
            return Results.redirect("/login");
        }
        
        return execute();
    }
    
    protected Result execute() {
        return ok("need to be overwrited!");
    }
    
    private boolean isValidPermission() {
        String username = session("username");
        if (username == null || username.trim().length() == 0) {
            return false;
        }
        
        user = BankUser.getByUserName(username);
        if (user == null) {
            session().clear();
            return false;
        }
        
        return true;
    }
}
