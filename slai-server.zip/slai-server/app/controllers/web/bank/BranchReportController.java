package controllers.web.bank;

import controllers.web.WebController;
import entities.BranchReport;
import models.Branch;
import play.mvc.*;

public class BranchReportController extends WebController {
    private String companyCode;
    private String branchCode;
    
    public Result show(String companyCode, String branchCode) {
        this.companyCode = companyCode;
        this.branchCode = branchCode;
        return show();
    }
    
    public Result execute() {
        BranchReport report = new BranchReport();
        Branch branch = Branch.getByCompanyCodeAndBranchCode(companyCode, branchCode);
        if (branch == null) {
            return Results.notFound("Ooop! Not found.");
        }
        report.setBranch(branch);
        return Results.ok(views.html.branch_report.render(report));
    }
}
