package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class FileUtils {
    public static String getFilePath(String filePath) {
        return System.getProperty("user.dir") + "\\" + filePath;
    }
    public static List<String> getAllLine(String filePath) {
        List<String> lines = new ArrayList<String>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "MS932"))) {
            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null) {
                lines.add(sCurrentLine);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } 
        return lines;
    }
    public static String fileToString(String filePath) {
        StringBuilder strBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF8"))) {
            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null) {
                strBuilder.append(sCurrentLine);
                strBuilder.append(System.lineSeparator());
            }

        } catch (IOException e) {
            e.printStackTrace();
        } 
        return strBuilder.toString();
    }
    public static void exportToFile(String filePath, String content) {
        try {
            File file = new File(filePath);
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(content);
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
