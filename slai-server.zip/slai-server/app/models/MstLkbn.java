package models;

import java.util.Date;
import java.util.List;
import javax.persistence.*;
import com.avaje.ebean.Model;
import com.avaje.ebean.annotation.DbComment;

import play.data.format.Formats;

@SuppressWarnings("deprecation")
@Entity
@DbComment("勘定科目辞書大区分マスタ")
public class MstLkbn extends Model {
    @Id
    private long id;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("業態種別")
    private String dtptn;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("連単区分")
    private String rtkbn;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("大区分コード")
    private String lgcd;
    
    @Column(columnDefinition = "varchar(100)")
    @DbComment("科目名")
    private String lgname;
    
    @Column(columnDefinition = "varchar(7)")
    @DbComment("集約コード")
    private String lclctcd;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("科目属性")
    private String lsbjflg;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("入力属性")
    private String liptflg;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("分析属性")
    private String lanlflg;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("更新日")
    private Date updatedTime = new Date();

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("ユーザー更新日")
    private Date userUpdateTime = new Date();

    /* function */
    public static Finder<String, MstLkbn> find = new Finder<>(String.class, MstLkbn.class);
    
    public static List<MstLkbn> getAll() {
        return MstLkbn.find.all();
    }
    
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDtptn() {
        return dtptn;
    }

    public void setDtptn(String dtptn) {
        this.dtptn = dtptn;
    }

    public String getRtkbn() {
        return rtkbn;
    }

    public void setRtkbn(String rtkbn) {
        this.rtkbn = rtkbn;
    }

    public String getLgcd() {
        return lgcd;
    }

    public void setLgcd(String lgcd) {
        this.lgcd = lgcd;
    }

    public String getLgname() {
        return lgname;
    }

    public void setLgname(String lgname) {
        this.lgname = lgname;
    }

    public String getLclctcd() {
        return lclctcd;
    }

    public void setLclctcd(String lclctcd) {
        this.lclctcd = lclctcd;
    }

    public String getLsbjflg() {
        return lsbjflg;
    }

    public void setLsbjflg(String lsbjflg) {
        this.lsbjflg = lsbjflg;
    }

    public String getLanlflg() {
        return lanlflg;
    }

    public void setLanlflg(String lanlflg) {
        this.lanlflg = lanlflg;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getLiptflg() {
        return liptflg;
    }

    public void setLiptflg(String liptflg) {
        this.liptflg = liptflg;
    }

    public Date getUserUpdateTime() {
        return userUpdateTime;
    }

    public void setUserUpdateTime(Date userUpdateTime) {
        this.userUpdateTime = userUpdateTime;
    }
}