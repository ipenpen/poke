package controllers;

import java.util.List;

import models.MstLkbn;
import models.MstMkbn;
import models.MstSkbn;
import play.Logger;
import play.mvc.*;
import utils.FileUtils;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        return ok("Welcome to Scorelink AI application!");
    }
    
    private void init() {
    }
    
    private void initMstSkbn() {
        List<String> lines = FileUtils.getAllLine(FileUtils.getFilePath("data\\F_MST_SKBN.txt"));
        int count = 0;
        for (String line : lines) {
            if (line.trim().length() < 1) {
                continue;
            }
            count++;
            if (count % 1000 == 0) {
                Logger.info("count = " + count + "/" + lines.size());
            }
            
            String[] splits = line.split(",");
            MstSkbn model = new MstSkbn();
            model.setDtptn(getValue(splits[0]));
            model.setRtkbn(getValue(splits[1]));
            model.setrLgcd(getValue(splits[2]));
            model.setrMdcd(getValue(splits[3]));
            model.setSmcd(getValue(splits[4]));
            model.setSmname(getValue(splits[5]));
            model.setSclctcd(getValue(splits[6]));
            model.setSsbjflg(getValue(splits[7]));
            model.setSiptflg(getValue(splits[8]));
            model.setSanlflg(getValue(splits[9]));
            model.save();
        }
    }
    
    private void initMstMkbn() {
        List<String> lines = FileUtils.getAllLine(FileUtils.getFilePath("data\\F_MST_MKBN.txt"));
        int count = 0;
        for (String line : lines) {
            if (line.trim().length() < 1) {
                continue;
            }
            count++;
            if (count % 1000 == 0) {
                Logger.info("count = " + count + "/" + lines.size());
            }
            
            String[] splits = line.split(",");
            MstMkbn model = new MstMkbn();
            model.setDtptn(getValue(splits[0]));
            model.setRtkbn(getValue(splits[1]));
            model.setrLgcd(getValue(splits[2]));
            model.setMdcd(getValue(splits[3]));
            model.setMdname(getValue(splits[4]));
            model.setMclctcd(getValue(splits[5]));
            model.setMsbjflg(getValue(splits[6]));
            model.setMiptflg(getValue(splits[7]));
            model.setManlflg(getValue(splits[8]));
            model.save();
        }
    }
    
    private void initMstLkbn() {
        List<String> lines = FileUtils.getAllLine(FileUtils.getFilePath("data\\F_MST_LKBN.txt"));
        for (String line : lines) {
            if (line.trim().length() < 1) {
                continue;
            }
            
            String[] splits = line.split(",");
            MstLkbn model = new MstLkbn();
            model.setDtptn(getValue(splits[0]));
            model.setRtkbn(getValue(splits[1]));
            model.setLgcd(getValue(splits[2]));
            model.setLgname(getValue(splits[3]));
            model.setLclctcd(getValue(splits[4]));
            model.setLsbjflg(getValue(splits[5]));
            model.setLiptflg(getValue(splits[6]));
            model.setLanlflg(getValue(splits[7]));
            model.save();
        }
    }
    
    private String getValue(String value) {
        if (value.trim().startsWith("\"")) {
            return value.trim().substring(1, value.trim().length() - 1);
        } else {
            return value.trim();
        }
    }

}
