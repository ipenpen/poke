package models;

import java.util.Date;
import java.util.List;
import javax.persistence.*;
import com.avaje.ebean.Model;
import com.avaje.ebean.annotation.DbComment;
import play.data.format.Formats;

@SuppressWarnings("deprecation")
@Entity
@DbComment("勘定科目辞書小区分マスタ")
public class MstSkbn extends Model {
    @Id
    private long id;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("業態種別")
    private String dtptn;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("連単区分")
    private String rtkbn;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("大区分コード")
    private String rLgcd;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("中区分コード")
    private String rMdcd;
    
    @Column(columnDefinition = "varchar(4)")
    @DbComment("小区分コード")
    private String smcd;
    
    @Column(columnDefinition = "varchar(100)")
    @DbComment("科目名")
    private String smname;
    
    @Column(columnDefinition = "varchar(7)")
    @DbComment("集約コード")
    private String sclctcd;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("科目属性")
    private String ssbjflg;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("入力属性")
    private String siptflg;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("分析属性")
    private String sanlflg;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("更新日")
    private Date updatedTime = new Date();

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("ユーザー更新日")
    private Date userUpdateTime = new Date();

    /* function */
    public static Finder<String, MstSkbn> find = new Finder<>(String.class, MstSkbn.class);
    
    public static List<MstSkbn> getAll() {
        return MstSkbn.find.all();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDtptn() {
        return dtptn;
    }

    public void setDtptn(String dtptn) {
        this.dtptn = dtptn;
    }

    public String getRtkbn() {
        return rtkbn;
    }

    public void setRtkbn(String rtkbn) {
        this.rtkbn = rtkbn;
    }

    public String getrLgcd() {
        return rLgcd;
    }

    public void setrLgcd(String rLgcd) {
        this.rLgcd = rLgcd;
    }

    public String getrMdcd() {
        return rMdcd;
    }

    public void setrMdcd(String rMdcd) {
        this.rMdcd = rMdcd;
    }

    public String getSmcd() {
        return smcd;
    }

    public void setSmcd(String smcd) {
        this.smcd = smcd;
    }

    public String getSmname() {
        return smname;
    }

    public void setSmname(String smname) {
        this.smname = smname;
    }

    public String getSclctcd() {
        return sclctcd;
    }

    public void setSclctcd(String sclctcd) {
        this.sclctcd = sclctcd;
    }

    public String getSsbjflg() {
        return ssbjflg;
    }

    public void setSsbjflg(String ssbjflg) {
        this.ssbjflg = ssbjflg;
    }

    public String getSiptflg() {
        return siptflg;
    }

    public void setSiptflg(String siptflg) {
        this.siptflg = siptflg;
    }

    public String getSanlflg() {
        return sanlflg;
    }

    public void setSanlflg(String sanlflg) {
        this.sanlflg = sanlflg;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Date getUserUpdateTime() {
        return userUpdateTime;
    }

    public void setUserUpdateTime(Date userUpdateTime) {
        this.userUpdateTime = userUpdateTime;
    }
}