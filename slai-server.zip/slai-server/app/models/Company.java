package models;

import java.util.Date;
import java.util.List;
import javax.persistence.*;
import com.avaje.ebean.Model;
import com.avaje.ebean.annotation.DbComment;
import play.data.format.Formats;

@SuppressWarnings("deprecation")
@Entity
@DbComment("会社")
public class Company extends Model {
    @Id
    @Column(columnDefinition = "varchar(20)")
    @DbComment("会社コード")
    private String companyCode;
    
    @Column(columnDefinition = "varchar(255)")
    @DbComment("会社名称")
    private String companyName;
    
    @Column(columnDefinition = "varchar(400)")
    @DbComment("会社説明")
    private String description;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("登録日時")
    private Date registedTime = new Date();

    @Column(columnDefinition = "varchar(20)")
    @DbComment("登録ユーザーID")
    private String registedUserId = null;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("更新日時")
    private Date updatedTime = new Date();

    @Column(columnDefinition = "varchar(20)")
    @DbComment("更新ユーザーID")
    private String updatedUserId = null;

    /* function */
    public static Finder<String, Company> find = new Finder<>(String.class, Company.class);
    
    public static Company getByCompanyCode(String companyCode) {
        return Company.find.where().eq("company_code", companyCode).findUnique();
    }
    
    public static List<Company> getAll() {
        return Company.find.all();
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getRegistedTime() {
        return registedTime;
    }

    public void setRegistedTime(Date registedTime) {
        this.registedTime = registedTime;
    }

    public String getRegistedUserId() {
        return registedUserId;
    }

    public void setRegistedUserId(String registedUserId) {
        this.registedUserId = registedUserId;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getUpdatedUserId() {
        return updatedUserId;
    }

    public void setUpdatedUserId(String updatedUserId) {
        this.updatedUserId = updatedUserId;
    }
}