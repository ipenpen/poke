package models;

import java.util.Date;
import javax.persistence.*;
import com.avaje.ebean.Model;
import com.avaje.ebean.annotation.DbComment;
import play.data.format.Formats;

@SuppressWarnings("deprecation")
@Entity
@DbComment("地銀")
public class BankUser extends Model {
    @Id
    @Column(columnDefinition = "varchar(50)")
    @DbComment("ログインID")
    private String userName;
    
    @Column(columnDefinition = "varchar(32)")
    @DbComment("パスワード")
    private String password;
    
    @ManyToOne
    @DbComment("銀行コード")
    private Bank bank;
    
    @DbComment("有効フラグ")
    private boolean isActive;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("登録日時")
    private Date registedTime = new Date();

    @Column(columnDefinition = "varchar(20)")
    @DbComment("登録ユーザーID")
    private String registedUserId = null;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("更新日時")
    private Date updatedTime = new Date();

    @Column(columnDefinition = "varchar(20)")
    @DbComment("更新ユーザーID")
    private String updatedUserId = null;

    /* function */
    public static Finder<String, BankUser> find = new Finder<>(String.class, BankUser.class);
    
    public static BankUser getByUserName(String userName) {
        return BankUser.find.where().eq("user_name", userName).findUnique();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public Date getRegistedTime() {
        return registedTime;
    }

    public void setRegistedTime(Date registedTime) {
        this.registedTime = registedTime;
    }

    public String getRegistedUserId() {
        return registedUserId;
    }

    public void setRegistedUserId(String registedUserId) {
        this.registedUserId = registedUserId;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getUpdatedUserId() {
        return updatedUserId;
    }

    public void setUpdatedUserId(String updatedUserId) {
        this.updatedUserId = updatedUserId;
    }
}