package models;

import java.util.Date;
import java.util.List;
import javax.persistence.*;
import com.avaje.ebean.Model;
import com.avaje.ebean.annotation.DbComment;
import play.data.format.Formats;

@SuppressWarnings("deprecation")
@Entity
@DbComment("集約データ")
public class SummaryData extends Model {
    @Id
    private long id;
    
    @Column(columnDefinition = "varchar(20)")
    @DbComment("会社コード")
    private String companyCode;
    
    @Column(columnDefinition = "varchar(10)")
    @DbComment("支店コード")
    private String branchCode;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("連単区分") // 00：単独、01：連結
    private String division;

    @Column(columnDefinition = "varchar(6)")
    @DbComment("決算年月")
    private boolean yyyyMM;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("業態種別") // 01：一般法人、02：信販、03：リース、04：銀行、05：生命保険、06：損害保険、07：証券
    private String businessCategory;
    
    @Column(columnDefinition = "varchar(15)")
    @DbComment("業種コード")
    private String industryCode;
    
    @DbComment("集約データ")
    private String data;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("登録日時")
    private Date registedTime = new Date();

    @Column(columnDefinition = "varchar(20)")
    @DbComment("登録ユーザーID")
    private String registedUserId = null;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("更新日時")
    private Date updatedTime = new Date();

    @Column(columnDefinition = "varchar(20)")
    @DbComment("更新ユーザーID")
    private String updatedUserId = null;


    /* function */
    public static Finder<String, SummaryData> find = new Finder<>(String.class, SummaryData.class);
    
    public static SummaryData getById(long id) {
        return SummaryData.find.where().eq("id", id).findUnique();
    }
    
    public static List<SummaryData> getAll() {
        return SummaryData.find.all();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public boolean isYyyyMM() {
        return yyyyMM;
    }

    public void setYyyyMM(boolean yyyyMM) {
        this.yyyyMM = yyyyMM;
    }

    public String getBusinessCategory() {
        return businessCategory;
    }

    public void setBusinessCategory(String businessCategory) {
        this.businessCategory = businessCategory;
    }

    public String getIndustryCode() {
        return industryCode;
    }

    public void setIndustryCode(String industryCode) {
        this.industryCode = industryCode;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Date getRegistedTime() {
        return registedTime;
    }

    public void setRegistedTime(Date registedTime) {
        this.registedTime = registedTime;
    }

    public String getRegistedUserId() {
        return registedUserId;
    }

    public void setRegistedUserId(String registedUserId) {
        this.registedUserId = registedUserId;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getUpdatedUserId() {
        return updatedUserId;
    }

    public void setUpdatedUserId(String updatedUserId) {
        this.updatedUserId = updatedUserId;
    }
}