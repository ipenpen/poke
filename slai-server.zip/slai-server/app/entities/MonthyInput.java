package entities;

import java.util.ArrayList;
import java.util.List;

public class MonthyInput {
    private String companyCode;
    private String companyName;
    private String branchCode;
    private String branchName;
    private String accountNo;
    private String yearMonth;
    private List<MonthyInputRow> monthyInputRows = new ArrayList<MonthyInputRow>();
    
    public String getCompanyCode() {
        return companyCode;
    }
    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }
    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public String getBranchCode() {
        return branchCode;
    }
    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }
    public String getBranchName() {
        return branchName;
    }
    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }
    public String getAccountNo() {
        return accountNo;
    }
    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }
    public String getYearMonth() {
        return yearMonth;
    }
    public void setYearMonth(String yearMonth) {
        this.yearMonth = yearMonth;
    }
    public List<MonthyInputRow> getMonthyInputRows() {
        return monthyInputRows;
    }
    public void setMonthyInputRows(List<MonthyInputRow> monthyInputRows) {
        this.monthyInputRows = monthyInputRows;
    }
    public void addRow(MonthyInputRow monthyInputRow) {
        monthyInputRows.add(monthyInputRow);
    }
}
