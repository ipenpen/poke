package controllers.api.company;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import controllers.api.PostApi;
import entities.MonthyInput;
import entities.MonthyInputRow;

public class AddAnnualDataApi extends PostApi {
    private MonthyInput inputData = new MonthyInput();
    
    @Override
    protected void init() {
        apiName = "addTKCMonthyData";
    }
    
    protected boolean validateInput() {
        if (!isExist("companyName", "companyCode", "branchName", "branchCode", "accountNo", "yearMonth", "monthyInputRows")) {
            setErrorMessage(1, "common.validateInputError");
            return false;
        }
        
        inputData.setCompanyName(getString("companyName"));
        inputData.setCompanyCode(getString("companyCode"));
        inputData.setBranchName(getString("branchName"));
        inputData.setBranchCode(getString("branchCode"));
        inputData.setAccountNo(getString("accountNo"));
        inputData.setYearMonth(getString("yearMonth"));
        ArrayNode rows = getArrayNode("monthyInputRows");
        for (int i = 0; i < rows.size(); i++) {
            JsonNode row = rows.get(i);
            MonthyInputRow monthyInputRow = new MonthyInputRow();
            monthyInputRow.setSubject(row.get("subject").asText().trim());
            monthyInputRow.setAmount(row.get("amount").asLong());
            monthyInputRow.setBalance(row.get("balance").asLong());
            inputData.addRow(monthyInputRow);
        }
        
        return true;
    }
    
    protected void execute() {
        // TODO: 集約処理
        // TODO: 集約結果をDBに保存する
        
        responseNode.put("message", "データを追加しました。");
    }
}
