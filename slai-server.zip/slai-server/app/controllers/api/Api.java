package controllers.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import models.AccessToken;
import play.Logger;
import play.i18n.Messages;
import play.mvc.*;

public class Api extends Controller {
    protected JsonNode requestNode = null;
    protected String apiName = null;
    protected ObjectNode responseNode = null;
    protected boolean needCheckAccessToken = true;
    protected AccessToken accessToken = null;
    
    protected void init() {}
    
    protected boolean validateInput() {
        return true;
    }
    
    protected void execute() {}
    
    protected void setErrorMessage(int level, String key) {
        Logger.error(apiName + ": messageKey=" + key + "(" + Messages.get(key) + ")");
        responseNode.put("errorCode", key);
        responseNode.put("developerMessage", Messages.get(key));
    }
}
