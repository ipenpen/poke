package models;

import java.util.Date;
import java.util.List;
import javax.persistence.*;
import com.avaje.ebean.Model;
import com.avaje.ebean.annotation.DbComment;

import play.data.format.Formats;

@SuppressWarnings("deprecation")
@Entity
@DbComment("勘定科目辞書中区分マスタ")
public class MstMkbn extends Model {
    @Id
    private long id;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("業態種別")
    private String dtptn;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("連単区分")
    private String rtkbn;
    
    @Column(columnDefinition = "varchar(2)")
    @DbComment("大区分コード")
    private String rLgcd;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("MDCD")
    private String mdcd;
    
    @Column(columnDefinition = "varchar(100)")
    @DbComment("科目名")
    private String mdname;
    
    @Column(columnDefinition = "varchar(7)")
    @DbComment("集約コード")
    private String mclctcd;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("科目属性")
    private String msbjflg;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("入力属性")
    private String miptflg;
    
    @Column(columnDefinition = "varchar(1)")
    @DbComment("分析属性")
    private String manlflg;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("更新日")
    private Date updatedTime = new Date();

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("ユーザー更新日")
    private Date userUpdateTime = new Date();

    /* function */
    public static Finder<String, MstMkbn> find = new Finder<>(String.class, MstMkbn.class);
    
    public static List<MstMkbn> getAll() {
        return MstMkbn.find.all();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDtptn() {
        return dtptn;
    }

    public void setDtptn(String dtptn) {
        this.dtptn = dtptn;
    }

    public String getRtkbn() {
        return rtkbn;
    }

    public void setRtkbn(String rtkbn) {
        this.rtkbn = rtkbn;
    }

    public String getrLgcd() {
        return rLgcd;
    }

    public void setrLgcd(String rLgcd) {
        this.rLgcd = rLgcd;
    }

    public String getMdcd() {
        return mdcd;
    }

    public void setMdcd(String mdcd) {
        this.mdcd = mdcd;
    }

    public String getMdname() {
        return mdname;
    }

    public void setMdname(String mdname) {
        this.mdname = mdname;
    }

    public String getMclctcd() {
        return mclctcd;
    }

    public void setMclctcd(String mclctcd) {
        this.mclctcd = mclctcd;
    }

    public String getMsbjflg() {
        return msbjflg;
    }

    public void setMsbjflg(String msbjflg) {
        this.msbjflg = msbjflg;
    }

    public String getMiptflg() {
        return miptflg;
    }

    public void setMiptflg(String miptflg) {
        this.miptflg = miptflg;
    }

    public String getManlflg() {
        return manlflg;
    }

    public void setManlflg(String manlflg) {
        this.manlflg = manlflg;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Date getUserUpdateTime() {
        return userUpdateTime;
    }

    public void setUserUpdateTime(Date userUpdateTime) {
        this.userUpdateTime = userUpdateTime;
    }
}