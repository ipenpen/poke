package entities;

import models.Branch;

public class BranchReport {
    private Branch branch;
    
    public String getCompanyName() {
        return branch.getCompany().getCompanyName();
    }
    
    public String getCompanyCode() {
        return branch.getCompany().getCompanyCode();
    }
    
    public String getBranchName() {
        return branch.getBranchName();
    }
    
    public String getBranchCode() {
        return branch.getBranchCode();
    }

    public Branch getBranch() {
        return branch;
    }

    public void setBranch(Branch branch) {
        this.branch = branch;
    }
}
