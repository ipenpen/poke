package controllers.api;

import org.apache.commons.lang3.exception.ExceptionUtils;
import com.avaje.ebean.Ebean;
import com.fasterxml.jackson.databind.node.ArrayNode;

import controllers.api.utils.ErrorUtils;
import models.AccessToken;
import play.Logger;
import play.i18n.Messages;
import play.libs.Json;
import play.mvc.*;

public class PostApi extends Api {

    @BodyParser.Of(BodyParser.Json.class)
    public Result post() {
        // Cross Domain Access許可
        response().setHeader("Access-Control-Allow-Origin", "*");
        
        // データを準備
        responseNode = Json.newObject();
        init();
        
        // リクエストデータを取得
        requestNode = Controller.request().body().asJson();
        if (requestNode != null) {
            Logger.debug(apiName + requestNode.toString());
        }
        
        // アクセスキー審査
        if (needCheckAccessToken) {
            String token = request().getHeader("accessToken");
            if (token == null || token.length() == 0) {
                setErrorMessage(1, "common.invalidAccessToken");
                return Results.unauthorized(responseNode);
            }
            
            accessToken = AccessToken.getByTokenKey(token);
            if (accessToken == null) {
                setErrorMessage(1, "common.invalidAccessToken");
                return Results.unauthorized(responseNode);
            }
        }
        
        // 入力データ審査
        try {
            if (!validateInput()) {
                return Results.badRequest(responseNode);
            }
        } catch (Exception ex) {
            setErrorMessage(1, "common.validateInputError");
            return Results.badRequest(responseNode);
        }
        
        // マインの処理を実施
        Ebean.beginTransaction();
        try {
            execute();
            Ebean.commitTransaction();
        } catch (Exception ex) {
            Logger.error(apiName + ":" + ExceptionUtils.getStackTrace(ex));
            Ebean.rollbackTransaction();
            return Results.internalServerError(ErrorUtils.createJsonErrorMessage(Messages.get("common.exception")));
        } finally {
            Ebean.endTransaction();
        }
        
        // エラーがある場合
        if (responseNode.get("errorCode") != null) {
            return Results.badRequest(responseNode);
        }
        
        // 新規作成する場合： 201コードを返す、他の場合： 200コードを返す
        if ("post".equalsIgnoreCase(request().method())) {
            return Results.created(responseNode);
        } else {
            return Results.ok(responseNode);
        }
    }

    protected boolean isExist(String... keys) {
        if (requestNode == null) {
            return false;
        }
        for (String key : keys) {
            if (isMissingNode(key)) {
                return false;
            }
        }
        
        return true;
    }
    
    protected boolean hasNode(String key) {
        return !requestNode.findPath(key).isMissingNode();
    }
    
    protected boolean isMissingNode(String key) {
        return requestNode.findPath(key).isMissingNode();
    }
    
    protected String getString(String key) {
        return requestNode.findPath(key).asText().trim();
    }
    
    protected long getLong(String key) {
        return requestNode.findPath(key).asLong();
    }
    
    protected int getInteger(String key) {
        return requestNode.findPath(key).asInt();
    }
    
    protected double getDouble(String key) {
        return requestNode.findPath(key).asDouble();
    }
    
    protected Boolean getBoolean(String key) {
        return requestNode.findPath(key).asBoolean();
    }
    
    protected ArrayNode getArrayNode(String key) {
        return (ArrayNode) requestNode.get(key);
    }
}
