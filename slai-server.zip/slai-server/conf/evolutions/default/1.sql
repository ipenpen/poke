# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table access_token (
  access_token                  varchar(64) not null comment 'アクセスキー',
  description                   varchar(255) comment '説明',
  company_code                  varchar(10) comment 'アクセス元の企業コード',
  company_name                  varchar(100) comment 'アクセス元の企業名',
  is_active                     tinyint(1) default 0 comment '有効フラグ',
  accept_ip_addresses           varchar(255) comment '許可アクセス元IPアドレス一覧',
  registed_time                 datetime comment '登録日時',
  updated_time                  datetime comment '更新日時',
  constraint pk_access_token primary key (access_token)
) comment='APIのアクセス権限管理';

create table bank (
  bank_code                     varchar(10) not null comment '銀行コード',
  bank_name                     varchar(10) comment '銀行名称',
  description                   varchar(400) comment '説明',
  registed_time                 datetime comment '登録日時',
  registed_user_id              varchar(20) comment '登録ユーザーID',
  updated_time                  datetime comment '更新日時',
  updated_user_id               varchar(20) comment '更新ユーザーID',
  constraint pk_bank primary key (bank_code)
) comment='地銀';

create table bank_user (
  user_name                     varchar(50) not null comment 'ログインID',
  password                      varchar(32) comment 'パスワード',
  bank_bank_code                varchar(10),
  is_active                     tinyint(1) default 0 comment '有効フラグ',
  registed_time                 datetime comment '登録日時',
  registed_user_id              varchar(20) comment '登録ユーザーID',
  updated_time                  datetime comment '更新日時',
  updated_user_id               varchar(20) comment '更新ユーザーID',
  constraint pk_bank_user primary key (user_name)
) comment='地銀';

create table branch (
  id                            bigint auto_increment not null,
  company_company_code          varchar(20),
  branch_code                   varchar(10) comment '支店コード',
  branch_name                   varchar(255) comment '支店名称',
  description                   varchar(400) comment '支店説明',
  registed_time                 datetime comment '登録日時',
  registed_user_id              varchar(20) comment '登録ユーザーID',
  updated_time                  datetime comment '更新日時',
  updated_user_id               varchar(20) comment '更新ユーザーID',
  constraint pk_branch primary key (id)
) comment='会社の支店';

create table company (
  company_code                  varchar(20) not null comment '会社コード',
  company_name                  varchar(255) comment '会社名称',
  description                   varchar(400) comment '会社説明',
  registed_time                 datetime comment '登録日時',
  registed_user_id              varchar(20) comment '登録ユーザーID',
  updated_time                  datetime comment '更新日時',
  updated_user_id               varchar(20) comment '更新ユーザーID',
  constraint pk_company primary key (company_code)
) comment='会社';

create table mst_lkbn (
  id                            bigint auto_increment not null,
  dtptn                         varchar(2) comment '業態種別',
  rtkbn                         varchar(2) comment '連単区分',
  lgcd                          varchar(2) comment '大区分コード',
  lgname                        varchar(100) comment '科目名',
  lclctcd                       varchar(7) comment '集約コード',
  lsbjflg                       varchar(1) comment '科目属性',
  liptflg                       varchar(1) comment '入力属性',
  lanlflg                       varchar(1) comment '分析属性',
  updated_time                  datetime comment '更新日',
  user_update_time              datetime comment 'ユーザー更新日',
  constraint pk_mst_lkbn primary key (id)
) comment='勘定科目辞書大区分マスタ';

create table mst_mkbn (
  id                            bigint auto_increment not null,
  dtptn                         varchar(2) comment '業態種別',
  rtkbn                         varchar(2) comment '連単区分',
  r_lgcd                        varchar(2) comment '大区分コード',
  mdcd                          varchar(1) comment 'MDCD',
  mdname                        varchar(100) comment '科目名',
  mclctcd                       varchar(7) comment '集約コード',
  msbjflg                       varchar(1) comment '科目属性',
  miptflg                       varchar(1) comment '入力属性',
  manlflg                       varchar(1) comment '分析属性',
  updated_time                  datetime comment '更新日',
  user_update_time              datetime comment 'ユーザー更新日',
  constraint pk_mst_mkbn primary key (id)
) comment='勘定科目辞書中区分マスタ';

create table mst_skbn (
  id                            bigint auto_increment not null,
  dtptn                         varchar(2) comment '業態種別',
  rtkbn                         varchar(2) comment '連単区分',
  r_lgcd                        varchar(2) comment '大区分コード',
  r_mdcd                        varchar(1) comment '中区分コード',
  smcd                          varchar(4) comment '小区分コード',
  smname                        varchar(100) comment '科目名',
  sclctcd                       varchar(7) comment '集約コード',
  ssbjflg                       varchar(1) comment '科目属性',
  siptflg                       varchar(1) comment '入力属性',
  sanlflg                       varchar(1) comment '分析属性',
  updated_time                  datetime comment '更新日',
  user_update_time              datetime comment 'ユーザー更新日',
  constraint pk_mst_skbn primary key (id)
) comment='勘定科目辞書小区分マスタ';

create table summary_data (
  id                            bigint auto_increment not null,
  company_code                  varchar(20) comment '会社コード',
  branch_code                   varchar(10) comment '支店コード',
  division                      varchar(2) comment '連単区分',
  yyyy_mm                       varchar(6) comment '決算年月',
  business_category             varchar(2) comment '業態種別',
  industry_code                 varchar(15) comment '業種コード',
  data                          varchar(255) comment '集約データ',
  registed_time                 datetime comment '登録日時',
  registed_user_id              varchar(20) comment '登録ユーザーID',
  updated_time                  datetime comment '更新日時',
  updated_user_id               varchar(20) comment '更新ユーザーID',
  constraint pk_summary_data primary key (id)
) comment='集約データ';

alter table bank_user add constraint fk_bank_user_bank_bank_code foreign key (bank_bank_code) references bank (bank_code) on delete restrict on update restrict;
create index ix_bank_user_bank_bank_code on bank_user (bank_bank_code);

alter table branch add constraint fk_branch_company_company_code foreign key (company_company_code) references company (company_code) on delete restrict on update restrict;
create index ix_branch_company_company_code on branch (company_company_code);


# --- !Downs

alter table bank_user drop foreign key fk_bank_user_bank_bank_code;
drop index ix_bank_user_bank_bank_code on bank_user;

alter table branch drop foreign key fk_branch_company_company_code;
drop index ix_branch_company_company_code on branch;

drop table if exists access_token;

drop table if exists bank;

drop table if exists bank_user;

drop table if exists branch;

drop table if exists company;

drop table if exists mst_lkbn;

drop table if exists mst_mkbn;

drop table if exists mst_skbn;

drop table if exists summary_data;

