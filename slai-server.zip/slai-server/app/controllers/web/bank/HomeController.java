package controllers.web.bank;

import java.util.List;
import controllers.web.WebController;
import entities.CompanyList;
import models.Company;
import play.mvc.*;

public class HomeController extends WebController {

    public Result execute() {
        List<Company> companies = Company.getAll();
        CompanyList companyList = new CompanyList();
        companyList.setCompanies(companies);
        return Results.ok(views.html.companies.render(companyList));
    }
}
