package entities;

import java.util.ArrayList;
import java.util.List;
import models.Branch;

public class BranchList {
    private String companyCode;
    private String companyName;
    private List<Branch> branchs = new ArrayList<Branch>();
    
    public String getCompanyCode() {
        return companyCode;
    }
    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }
    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public List<Branch> getBranchs() {
        return branchs;
    }
    public void setBranchs(List<Branch> branchs) {
        this.branchs = branchs;
    }
}
