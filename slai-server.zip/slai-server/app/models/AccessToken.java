package models;

import java.util.Date;
import java.util.List;
import javax.persistence.*;
import com.avaje.ebean.Model;
import com.avaje.ebean.annotation.DbComment;
import play.data.format.Formats;

@SuppressWarnings("deprecation")
@Entity
@DbComment("APIのアクセス権限管理")
public class AccessToken extends Model {
    @Id
    @Column(columnDefinition = "varchar(64)")
    @DbComment("アクセスキー")
    private String accessToken;
    
    @Column(columnDefinition = "varchar(255)")
    @DbComment("説明")
    private String description;
    
    @Column(columnDefinition = "varchar(10)")
    @DbComment("アクセス元の企業コード")
    private String companyCode;
    
    @Column(columnDefinition = "varchar(100)")
    @DbComment("アクセス元の企業名")
    private String companyName;
    
    @DbComment("有効フラグ")
    private boolean isActive;
    
    @Column(columnDefinition = "varchar(255)")
    @DbComment("許可アクセス元IPアドレス一覧")
    private String acceptIpAddresses;

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("登録日時")
    private Date registedTime = new Date();

    @Formats.DateTime(pattern = "yyyy-MM-ddThh:mm:ss")
    @Column(columnDefinition = "datetime")
    @DbComment("更新日時")
    private Date updatedTime = new Date();

    /* function */
    public static Finder<String, AccessToken> find = new Finder<>(String.class, AccessToken.class);
    
    public static AccessToken getByTokenKey(String tokenKey) {
        return AccessToken.find.where().eq("access_token", tokenKey).findUnique();
    }
    
    public static List<AccessToken> getAll() {
        return AccessToken.find.all();
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public String getAcceptIpAddresses() {
        return acceptIpAddresses;
    }

    public void setAcceptIpAddresses(String acceptIpAddresses) {
        this.acceptIpAddresses = acceptIpAddresses;
    }

    public Date getRegistedTime() {
        return registedTime;
    }

    public void setRegistedTime(Date registedTime) {
        this.registedTime = registedTime;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }
}