#!/usr/bin/env bash

java -jar pokeclient.jar