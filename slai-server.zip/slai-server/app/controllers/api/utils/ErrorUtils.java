package controllers.api.utils;

import com.fasterxml.jackson.databind.node.ObjectNode;
import play.libs.Json;

public class ErrorUtils {
    public static ObjectNode createJsonErrorMessage(String message) {
        ObjectNode output = Json.newObject();
        output.put("message", message);

        return output;
    }
}